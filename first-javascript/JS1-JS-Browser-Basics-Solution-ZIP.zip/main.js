// Part 1:
alert('Hello Boulder!');

// Part 2:
var name = prompt('What is your name?');
alert('Hello ' + name + '!');